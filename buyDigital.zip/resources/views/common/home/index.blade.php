@extends('layouts.common')
@section('title', 'Home Page')

@section('content')

    <h4>Welcome To Home</h4>


@endsection
