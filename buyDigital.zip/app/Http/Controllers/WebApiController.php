<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;

class WebApiController extends Controller
{

    public function getStates($country_id)
    {


    }
}
